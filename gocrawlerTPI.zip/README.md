# gocrawlerTPI

A web crawler built in Go for crawling and parsing web content.

## Features

- Concurrent web crawling
- HTML parsing
- Data storage
- CSV/JSON export

## Project Structure

```
gocrawler/
├── crawler/     # Web crawling logic
├── parser/      # HTML parsing
├── storage/     # Data storage
├── web/         # Web interface
└── main.go      # Entry point
```

## Requirements

- Go 1.x or higher

## Build

```bash
go build -o crawler.exe
```

## Run

```bash
./crawler.exe
```
